/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.socket;
/**
 * @author student_user Dulal-213902116
 */

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Client_One_Way {
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 5000);
        System.out.println("Client Connected at server Handshaking port" + s.getPort());
        System.out.println("Client's communication port " + s.getLocalPort());
        System.out.println("Client connected ");
        System.out.println("Enter the message that you want to send and send \"stop\" to close the connection: ");
        DataOutputStream output = new DataOutputStream(s.getOutputStream());
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
        String str = "";
        while (!str.equals("stop")) {
            str = read.readLine();
            output.writeUTF(str);
        }

        output.close();
        read.close();
        s.close();
    }
}
