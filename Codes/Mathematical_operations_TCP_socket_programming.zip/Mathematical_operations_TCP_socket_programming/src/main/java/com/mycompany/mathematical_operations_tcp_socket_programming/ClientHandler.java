/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mathematical_operations_tcp_socket_programming;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author student_user
 */
class ClientHandler extends Thread {

    final Socket clientSocket;
    final DataInputStream dis;
    final DataOutputStream dos;

    public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos) {
        this.clientSocket = s;
        this.dis = dis;
        this.dos = dos;
    }

    public void run() {
        try {
            while (true) {
                int num1 = dis.readInt(); // Read first integer from client
                int num2 = dis.readInt(); // Read second integer from client
                String operator = dis.readUTF(); // Read operator from client

                int result = 0;

                switch (operator) {
                    case "Sum":
                        result = num1 + num2;
                        break;
                    case "Subtract":
                        result = num1 - num2;
                        break;
                    case "Multiplication":
                        result = num1 * num2;
                        break;
                    case "Division":
                        result = num1 / num2;
                        break;
                    case "Modules":
                        result = num1 % num2;
                        break;
                    case "ENDS": // Client ends connection
                        System.out.println("Client " + this.clientSocket + " has ended the connection");
                        this.clientSocket.close();
                        return; // End the thread
                    default:
                        dos.writeUTF("Invalid operator");
                        continue; // Continue to listen for next input
                }

                dos.writeInt(result); // Send result to client
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                // Closing resources
                this.dis.close();
                this.dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
