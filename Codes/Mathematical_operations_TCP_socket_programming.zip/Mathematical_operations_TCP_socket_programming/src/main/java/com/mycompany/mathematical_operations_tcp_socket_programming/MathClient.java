/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mathematical_operations_tcp_socket_programming;

/**
 *
 * @author student_user
 */
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MathClient {
    public static void main(String args[]) throws IOException {
        try {
            Socket clientSocket = new Socket("localhost", 5000);
            System.out.println("Connected at server Handshaking port " + clientSocket.getPort());
            System.out.println("Client is connecting at Communication Port " + clientSocket.getLocalPort());
            System.out.println("Client is Connected");

            Scanner scanner = new Scanner(System.in);
            DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());
            DataInputStream dis = new DataInputStream(clientSocket.getInputStream());

            while (true) {
                System.out.println("Enter first integer:");
                int num1 = scanner.nextInt();
                System.out.println("Enter second integer:");
                int num2 = scanner.nextInt();
                System.out.println("Enter operation (Sum, Subtract, Multiplication, Division, Modules, or ENDS to exit):");
                String operator = scanner.next();

                dos.writeInt(num1); // Send first integer to server
                dos.writeInt(num2); // Send second integer to server
                dos.writeUTF(operator); // Send operator to server

                if (operator.equals("ENDS")) {
                    System.out.println("Closing the connection " + clientSocket);
                    clientSocket.close();
                    System.out.println("Connection Closed");
                    break;
                }

                int result = dis.readInt(); // Receive result from server
                System.out.println("Result: " + result);
            }

            dos.close();
            dis.close();
            scanner.close();
            clientSocket.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
