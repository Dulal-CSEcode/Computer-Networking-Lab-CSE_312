/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mathematical_operations_tcp_socket_programming;

/**
 *
 * @author student_user
 */
public class Mathematical_operations_TCP_socket_programming {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
