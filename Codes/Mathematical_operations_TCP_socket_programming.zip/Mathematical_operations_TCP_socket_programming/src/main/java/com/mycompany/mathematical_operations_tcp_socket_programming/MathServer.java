/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mathematical_operations_tcp_socket_programming;

/**
 *
 * @author student_user
 */
import java.io.*;
import java.net.*;

public class MathServer {
    public static void main(String args[]) throws IOException {
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server connected at " + serverSocket.getLocalPort());
        System.out.println("Server is connecting\n");
        System.out.println("Waiting for the client\n");
        
        int clientCount = 0; // To keep track of the number of clients served
        
        while (clientCount < 5) { // Server can serve at most 5 clients
            Socket clientSocket = serverSocket.accept();
            System.out.println("A new client is connected " + clientSocket);
            
            DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());
            DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
            
            System.out.println("A new thread is assigning");
            Thread clientHandlerThread = new ClientHandler(clientSocket, dis, dos);
            clientHandlerThread.start();
            
            clientCount++; // Increment client count
        }
        serverSocket.close(); // Close server socket after serving 5 clients
    }
}

