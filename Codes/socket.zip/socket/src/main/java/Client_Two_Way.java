/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * @author student_user
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Client_Two_Way {
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 5000);
        System.out.println("Client Connected at server Handshaking port" + s.getPort());
        System.out.println("Client's communication port " + s.getLocalPort());
        System.out.println("Client connected ");
        
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream output = new DataOutputStream(s.getOutputStream());
        DataInputStream input = new DataInputStream(s.getInputStream());
        
        String str = "";
        while (!str.equals("stop")) {
            System.out.println("Enter message to send to server ('stop' to end): ");
            str = read.readLine();
            output.writeUTF(str);
            output.flush(); // Flush the output stream to ensure the message is sent immediately
            
            if(str.equals("stop"))
                break;
            
            str = input.readUTF();
            System.out.println("Server Says: " + str);
        }

        output.close();
        input.close();
        read.close();
        s.close();
    }
}

