/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * @author Dulal-213902116
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Client_Two_Way {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 5000);
        System.out.println("Client Connected at server Handshaking port" + socket.getPort());
        System.out.println("Client's communication port " + socket.getLocalPort());
        System.out.println("Client connected ");

        BufferedReader clientReader = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream outputToServer = new DataOutputStream(socket.getOutputStream());
        DataInputStream inputFromServer = new DataInputStream(socket.getInputStream());

        String clientMsg = "";
        String serverMsg = "";

        while (!clientMsg.equals("stop") && !serverMsg.equals("stop")) 
        {
            // Client sends message to server
            System.out.println("Enter message to send to server ('stop' to end): ");
            clientMsg = clientReader.readLine();
            outputToServer.writeUTF(clientMsg);
            outputToServer.flush();

            if (clientMsg.equals("stop")) 
            {
                break;
            }

            // Client receives message from server
            serverMsg = inputFromServer.readUTF();
            System.out.println("Server Says: " + serverMsg);

            if (serverMsg.equals("stop")) 
            {
                break;
            }
        }

        // Closing resources
        outputToServer.close();
        inputFromServer.close();
        clientReader.close();
        socket.close();
    }
}
