/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * @author Dulal-213902116
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server_Two_Way  {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server is connected at port no: " + serverSocket.getLocalPort());

        System.out.println("Server is connecting\n");
        System.out.println("Waiting for the client\n");

        Socket clientSocket = serverSocket.accept();
        System.out.println("Client request is accepted at port no: " + clientSocket.getPort());

        System.out.println("Server’s Communication Port: " + clientSocket.getLocalPort());

        DataInputStream inputFromClient = new DataInputStream(clientSocket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(clientSocket.getOutputStream());

        BufferedReader serverReader = new BufferedReader(new InputStreamReader(System.in));

        String clientMsg = "";
        String serverMsg = "";

        while (!clientMsg.equals("stop") && !serverMsg.equals("stop")) 
        {
            // Server sends message to client
            System.out.println("Enter message to send to client ('stop' to end): ");
            serverMsg = serverReader.readLine();
            outputToClient.writeUTF(serverMsg);
            outputToClient.flush();

            if (serverMsg.equals("stop")) 
            {
                break;
            }

            // Server receives message from client
            clientMsg = inputFromClient.readUTF();
            System.out.println("Client Says: " + clientMsg);

            if (clientMsg.equals("stop")) 
            {
                break;
            }
        }

        // Closing resources
        clientSocket.close();
        inputFromClient.close();
        outputToClient.close();
        serverSocket.close();
    }
}
