/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * @author student_user
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server_Two_Way {
    
    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(5000);
        System.out.println("Server is connected at port no: " + ss.getLocalPort());

        System.out.println("Server is connecting\n");
        System.out.println("Waiting for the client\n");

        Socket s = ss.accept();
        System.out.println("Client request is accepted at port no: " + s.getPort());

        System.out.println("Server’s Communication Port: " + s.getLocalPort());
        DataInputStream input = new DataInputStream(s.getInputStream());
        DataOutputStream output = new DataOutputStream(s.getOutputStream());
        
        String str = "";

        while (!str.equals("stop")) {
            str = input.readUTF();
            System.out.println("Client Says: " + str);
            
            System.out.println("Enter response to client ('stop' to end): ");
            str = input.readLine();
            output.writeUTF(str);
            output.flush(); // Flush the output stream to ensure the message is sent immediately
        }

        s.close();
        input.close();
        output.close();
        ss.close(); // Close the server socket when done.
    }
}

